#include "stdafx.h"
#include "RBoundary.h"

RBoundary::RBoundary(void)
{
}

RBoundary::~RBoundary(void)
{
	//for( iterCOList itr = mChildren.begin(); itr != mChildren.end(); ++itr )
	//{
	//	SAFE_DELETE(*itr);
	//}
	//mChildren.clear();
}