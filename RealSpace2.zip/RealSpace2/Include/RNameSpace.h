#pragma once

#define _NAMESPACE_REALSPACE2_BEGIN		namespace RealSpace2{
#define _NAMESPACE_REALSPACE2_END		}
#define _RS2							RealSpace2
#define _REALSPACE2						RealSpace2
#define _USING_NAMESPACE_REALSPACE2		using namespace RealSpace2;
