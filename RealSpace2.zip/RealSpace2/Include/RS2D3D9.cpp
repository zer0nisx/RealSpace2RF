#include "stdafx.h"
#include "RS2D3D9.h"
#include "RealSpace2.h"

int RS2D3D9::Create(HWND hWnd, IDirect3D9* D3D)
{
	return true;
}
