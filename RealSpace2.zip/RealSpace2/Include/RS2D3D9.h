#pragma once

class RS2D3D9
{
public:
	int Create(HWND hWnd, IDirect3D9* D3D);
};